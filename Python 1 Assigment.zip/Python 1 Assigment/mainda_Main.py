from mainda_Functions import remove_multi_abbreviations

def main():
    print("ABBREVIATION OF WORDS FROM USER FILE")
    print("**********************************")

    # User input file
    input_filename = input("Please enter filename (without .txt extension): ")
    surname = input("Enter surname: ")

    # Output filename
    output_filename = f"{surname}_{input_filename}_abbrevs.txt"

    # Reading names from input file
    infile = open(f"{input_filename}.txt", 'r')
    names = [line.strip() for line in infile if line.strip()]
    infile.close()

    # Processing names and generating unique abbreviations
    result = remove_multi_abbreviations(names)

    # Writing results to output file
    outfile = open(output_filename, 'w')
    for name in names:
        outfile.write(f"{name}\n")
        outfile.write(f"{result[name]}\n")
    outfile.close()

    print(f"\nYour results is written to {output_filename} in the same directory.")

if __name__ == "__main__":
    main()
    

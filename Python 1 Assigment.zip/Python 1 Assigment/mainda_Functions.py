import re

# This dictionary will hold letters and their values from file
letter_values = {}

# This is the path of values.txt in my laptop
infile = open(r'D:/STUDIES/DATA SCIENCE VIDEOS/PROGRAMMING FOR DATA/Assign Py/values.txt', 'r')
langlist = infile.readlines()
infile.close()

# This Loop populates the letter_values dictionary
for line in langlist:
    letter, value = line.strip().split()
    letter_values[letter.upper()] = int(value)

def assgn_value(letter):
    """Retrieves the value of a letter from letter_values."""
    return letter_values.get(letter.upper(), 0)

def text_formating(word): 
    """Takes a word and removes special characters"""
    formatted_text = re.sub(r"[^a-zA-Z]", " ", word)
    return formatted_text.split()

def calc_marks(letter, position, word_length, is_first_letter=False):
    """This function calculates score of a letter based on its position and its value as specified in values.txt file."""
    if is_first_letter:
        return 0
    letter_upper = letter.upper()
    letter_value = letter_values.get(letter_upper, 0)
    if position == word_length - 1:
        if letter_upper == 'E':
           return 20
        return 5
    if position == 1:
        return 1 + letter_value
    if position == 2:
        return 2 + letter_value
    return 3 + letter_value

def makeAbbreviations(name): # this function produces acceptable abbreviations for a name.
    
    words = re.sub(r"[^a-zA-Z]", " ", name).upper().split()
    AcceptableAbbrevs = {}

    # This condition checks if the name has enough letters for a three-letter abbreviation
    if len(words) < 1 or sum(len(word) for word in words) < 3:
        return AcceptableAbbrevs

    first_letter = words[0][0] 
    for i, w1 in enumerate(words):
        for i_position, char1 in enumerate(w1):
            if i_position == 0:
                continue
            for j, w2 in enumerate(words[i:], start=i):  # Ensures subsequent words are processed
                for j_position, char2 in enumerate(w2):
                    # Ensures the third letter comes after the second letter
                    if i == j and j_position <= i_position:
                        continue
                    abbrev = first_letter + char1 + char2
                    total = (
                        calc_marks(char1, i_position, len(w1)) +
                        calc_marks(char2, j_position, len(w2))
                    )
                    if abbrev not in AcceptableAbbrevs or total < AcceptableAbbrevs[abbrev]:
                        AcceptableAbbrevs[abbrev] = total
    return AcceptableAbbrevs

def remove_multi_abbreviations(names):
    """this function removes duplicate abbreviations, keeps the best for each name."""
    name_abbrevs = {}
    all_abbrevs = set()
    duplicate_abbrevs = set()

    for name in names:
        abbrevs = makeAbbreviations(name)
        name_abbrevs[name] = abbrevs

        for abbrev in abbrevs:
            if abbrev in all_abbrevs:
                duplicate_abbrevs.add(abbrev)
            all_abbrevs.add(abbrev)

    result = {}
    for name in names:
        abbrevs = name_abbrevs[name]
        AcceptableAbbrevs = {k: v for k, v in abbrevs.items() if k not in duplicate_abbrevs}
        if AcceptableAbbrevs:
            min_score = min(AcceptableAbbrevs.values())
            best_abbrevs = [k for k, v in AcceptableAbbrevs.items() if v == min_score]
            result[name] = ' '.join(sorted(best_abbrevs))
        else:
            result[name] = ''

    return result

